\<?php
session_start();

// Include the database connection file
include '../includes/db.php';  // Make sure the path is correct

$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $regno = trim($_POST['regno']);
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate password
    if ($new_password !== $confirm_password) {
        $msg = "Passwords do not match.";
    } elseif (strlen($new_password) < 6) {
        $msg = "Password must be at least 6 characters.";
    } else {
        // Prepare statement to get user by regno
        $stmt = $conn->prepare("SELECT id, password FROM users WHERE regno = ?");
        $stmt->bind_param("s", $regno);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($id, $hashed_password);

        if ($stmt->num_rows > 0) {
            // Update password in the database
            $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);

            $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE regno = ?");
            $update_stmt->bind_param("ss", $hashed_new_password, $regno);

            if ($update_stmt->execute()) {
                $msg = "Password updated successfully.";
            } else {
                $msg = "Error updating password. Please try again.";
            }
        } else {
            $msg = "Student with this registration number not found.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password - Placement App</title>
    <style>
        body {
            background: linear-gradient(to right, #28a745, #007bff); /* Green to Blue Gradient */
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
        }
        .forgot-password-box {
            width: 350px;
            margin: 120px auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            text-align: center;
        }
        h2 {
            margin-bottom: 25px;
            color: #333;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px;
            margin: 8px 0 16px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #218838;
        }
        .msg {
            color: red;
            margin-bottom: 15px;
        }
        .footer-links {
            margin-top: 15px;
            font-size: 14px;
        }
        .footer-links a {
            color: #0062cc;
            text-decoration: none;
        }
        .footer-links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="forgot-password-box">
        <h2>Forgot Password</h2>

        <?php if ($msg): ?>
            <div class="msg"><?php echo $msg; ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="text" name="regno" placeholder="Registration Number" required autofocus />
            <input type="password" name="new_password" placeholder="New Password" required />
            <input type="password" name="confirm_password" placeholder="Confirm Password" required />
            <button type="submit">Update Password</button>
        </form>

        <div class="footer-links">
            <p>Back to <a href="studentlogin.php">Login</a></p>
        </div>
    </div>
</body>
</html>
