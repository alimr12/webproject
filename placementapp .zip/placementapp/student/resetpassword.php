<?php
session_start();
include '../includes/db.php';

$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];
    $token = $_GET['token'];

    // Validate token
    $stmt = $conn->prepare("SELECT userid FROM password_resets WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($userid);
        $stmt->fetch();

        // Check if passwords match
        if ($newPassword !== $confirmPassword) {
            $msg = "Passwords do not match.";
        } elseif (strlen($newPassword) < 6) {
            $msg = "Password must be at least 6 characters.";
        } else {
            // Update password in the users table
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $hashedPassword, $userid);
            $stmt->execute();

            // Delete the token after use
            $stmt = $conn->prepare("DELETE FROM password_resets WHERE token = ?");
            $stmt->bind_param("s", $token);
            $stmt->execute();

            $msg = "Your password has been reset successfully. You can now <a href='../student/studentlogin.php'>login</a>.";
        }
    } else {
        $msg = "Invalid or expired token.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Reset Password - Placement App</title>
    <style>
        body {
            background: linear-gradient(to right, #007bff, #0062cc);
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .login-box {
            width: 350px;
            margin: 120px auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            text-align: center;
        }
        h2 {
            margin-bottom: 25px;
            color: #333;
        }
        input[type="password"] {
            width: 100%;
            padding: 12px;
            margin: 8px 0 16px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #218838;
        }
        .msg {
            color: red;
            margin-bottom: 15px;
        }
        .back-link {
            margin-top: 15px;
            font-size: 14px;
        }
        .back-link a {
            color: #0062cc;
            text-decoration: none;
        }
        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>Reset Password</h2>

        <?php if ($msg): ?>
            <div class="msg"><?php echo $msg; ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <input type="password" name="new_password" placeholder="New Password" required />
            <input type="password" name="confirm_password" placeholder="Confirm New Password" required />
            <button type="submit">Reset Password</button>
        </form>

        <div class="back-link">
            <a href="../student/studentlogin.php">Back to Login</a>
        </div>
    </div>
</body>
</html>
