<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Ensure the student is logged in
if (!isset($_SESSION['userid']) || $_SESSION['role'] !== 'student') {
    header("Location: studentlogin.php");
    exit();
}

include '../includes/db.php';

$studentName = $_SESSION['name'];
$studentId = $_SESSION['userid'];

// Check how many consents already submitted by student
$consentLimit = 3;
$studentConsentCountQuery = $conn->prepare("SELECT COUNT(*) FROM consents WHERE userid = ?");
$studentConsentCountQuery->bind_param("i", $studentId);
$studentConsentCountQuery->execute();
$studentConsentCountQuery->bind_result($studentConsentCount);
$studentConsentCountQuery->fetch();
$studentConsentCountQuery->close();

// Fetch organizations with applied/placed counts
$orgsQuery = "
    SELECT o.id, o.name AS org_name, o.location, o.domain, o.seats,
        (SELECT COUNT(*) FROM consents c WHERE c.orgid = o.id AND c.status = 'inprocess') AS applied_count,
        (SELECT COUNT(*) FROM finalplacements f WHERE f.orgid = o.id) AS placed_count
    FROM organizations o
";
$orgs = $conn->query($orgsQuery);

// Fetch placement info
$placementQuery = "
    SELECT o.name, o.location, o.domain, f.placed_date 
    FROM finalplacements f 
    JOIN organizations o ON f.orgid = o.id 
    WHERE f.userid = ?
";
$stmt = $conn->prepare($placementQuery);
$stmt->bind_param("i", $studentId);
$stmt->execute();
$placedResult = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard - Placement App</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #28a745, #007bff); /* Green to Blue Gradient */
            color: #fff;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1000px;
            margin: 60px auto;
            background-color: rgba(255, 255, 255, 0.95);
            color: #333;
            padding: 30px;
            border-radius: 10px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 40px;
        }

        th, td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f3f3f3;
        }

        a.button {
            padding: 8px 15px;
            background-color: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }

        a.button:hover {
            background-color: #218838;
        }

        .logout-btn {
            display: block;
            text-align: center;
            margin-top: 2px;
            padding: 12px 20px;
            background-color: #red;
            color: red;
            text-decoration: none;
            font-weight: bold;
            border-radius: 2px;
        }

        .logout-btn:hover {
            background-color: red;
        }

    </style>
</head>
<body>

<div class="container">
    <h2>Welcome, <?= htmlspecialchars($studentName) ?>!</h2>

    <h3>📋 Available Organizations</h3>
    <table>
        <tr>
            <th>Company</th>
            <th>Location</th>
            <th>Domain</th>
            <th>Seats</th>
            <th>Apply</th>
        </tr>

        <?php while ($org = $orgs->fetch_assoc()): ?>
            <?php
                $orgid = $org['id'];
                $remainingSeats = $org['seats'] - $org['placed_count'];

                // Check consent status
                $consentStatusQuery = $conn->prepare("SELECT status FROM consents WHERE userid = ? AND orgid = ?");
                $consentStatusQuery->bind_param("ii", $studentId, $orgid);
                $consentStatusQuery->execute();
                $consentStatusQuery->store_result();
                $consentStatusQuery->bind_result($status);
                $hasConsent = $consentStatusQuery->num_rows > 0;
                $consentStatusQuery->fetch();
                $consentStatusQuery->close();

                // Check placement status
                $isPlacedQuery = $conn->prepare("SELECT COUNT(*) FROM finalplacements WHERE userid = ? AND orgid = ?");
                $isPlacedQuery->bind_param("ii", $studentId, $orgid);
                $isPlacedQuery->execute();
                $isPlacedQuery->bind_result($isPlacedCount);
                $isPlacedQuery->fetch();
                $isPlacedQuery->close();
            ?>

            <tr>
                <td><?= htmlspecialchars($org['org_name']) ?></td>
                <td><?= htmlspecialchars($org['location']) ?></td>
                <td><?= htmlspecialchars($org['domain']) ?></td>
                <td><?= $remainingSeats > 0 ? $remainingSeats : 'Full' ?></td>
                <td>
                    <?php if ($isPlacedCount > 0): ?>
                        <span>Placed</span>
                    <?php elseif ($hasConsent && $status === 'inprocess'): ?>
                        <span>In Progress</span>
                    <?php elseif ($studentConsentCount >= 3): ?>
                        <span>Limit Reached</span>
                    <?php elseif ($remainingSeats <= 0): ?>
                        <span>Not Available</span>
                    <?php else: ?>
                        <a class="button" href="consentform.php?orgid=<?= $orgid ?>">Give Consent</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <!-- Placement Info -->
    <h3>✅ Placement Status</h3>
    <?php if ($placedResult->num_rows > 0): ?>
        <?php $row = $placedResult->fetch_assoc(); ?>
        <p><strong>You have been placed in:</strong> <?= htmlspecialchars($row['name']) ?>  
        (<?= htmlspecialchars($row['domain']) ?>, <?= htmlspecialchars($row['location']) ?>)  
        on <?= date("d M Y", strtotime($row['placed_date'])) ?></p>
    <?php else: ?>
        <p><em>You have not been placed yet.</em></p>
    <?php endif; ?>

<div style="text-align: center;">
    <a href="logout.php" class="button logout-small">🚪 Logout</a>
</div>

</div>

</body>
</html>
