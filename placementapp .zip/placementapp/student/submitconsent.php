<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['userid'])) {
    header("Location: ../student/studentlogin.php");
    exit();
}

$studentId = $_SESSION['userid'];
$orgId = $_POST['org_id'];
$priority = $_POST['priority'];
$gpa = $_POST['gpa'];
$batch = $_POST['batch'];
$regno = $_POST['regno'];

// CV Upload Handling
$uploadDir = '../student/uploads/';
$cvName = basename($_FILES["cv"]["name"]);
$cvPath = $uploadDir . $cvName;

// Check directory validity
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
} elseif (!is_writable($uploadDir)) {
    die("Error: Upload directory is not writable.");
}

if (move_uploaded_file($_FILES["cv"]["tmp_name"], $cvPath)) {
    $relativePath = 'uploads/' . $cvName;
    $stmt = $conn->prepare("INSERT INTO consents (userid, orgid, priority, gpa, batch, regno, cv_path, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'inprocess')");
    $stmt->bind_param("iiissss", $studentId, $orgId, $priority, $gpa, $batch, $regno, $relativePath);
    
    if ($stmt->execute()) {
        header("Location: studentdashboard.php?success=1");
        exit();
    } else {
        echo "Error saving consent.";
    }
} else {
    echo "Error uploading CV.";
}
?>
