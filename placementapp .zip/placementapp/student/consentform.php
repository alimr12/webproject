<?php
include '../includes/db.php';
session_start();

// Ensure the student is logged in
if (!isset($_SESSION['userid']) || $_SESSION['role'] !== 'student') {
    header("Location: ../student/studentlogin.php");
    exit();
}

// Fetch the organization ID from the URL
$orgId = isset($_GET['orgid']) ? $_GET['orgid'] : null;
if (!$orgId) {
    echo "No organization selected!";
    exit();
}

// Fetch organization details for display
$orgResult = $conn->query("SELECT * FROM organizations WHERE id = $orgId");
$org = $orgResult->fetch_assoc();

// Fetch the student's current details (including regno, batch, and GPA)
$studentId = $_SESSION['userid'];
$studentName = $_SESSION['name'];

// Fetch the registration number (regno), batch, and GPA from the students table
$studentResult = $conn->query("SELECT regno, batch, gpa FROM students WHERE userid = $studentId");
$studentRow = $studentResult->fetch_assoc();
$regno = $studentRow['regno']; // Registration number
$batch = $studentRow['batch']; // Batch
$gpa = $studentRow['gpa']; // GPA

// Count the total number of applicants across all organizations
$totalApplicantsQuery = "SELECT COUNT(*) FROM consents";
$stmt = $conn->prepare($totalApplicantsQuery);
$stmt->execute();
$stmt->bind_result($totalApplicants);
$stmt->fetch();

// Maximum applicants allowed
$maxApplicants = 50;

// Check if we have reached the maximum applicants count
if ($totalApplicants >= $maxApplicants) {
    echo "<p>Sorry, the maximum number of applicants (17) has been reached for all organizations.</p>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Give Consent for <?php echo htmlspecialchars($org['name']); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background:linear-gradient(to right, #28a745, #007bff); /* Green to Blue Gradient */
            color: #fff;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 60px auto;
            background-color: rgba(255, 255, 255, 0.95);
            color: #333;
            padding: 30px;
            border-radius: 10px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        label, input, select {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border-radius: 6px;
        }
        button {
            width: 100%;
            padding: 12px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Give Consent for <?php echo htmlspecialchars($org['name']); ?></h2>

    <!-- Consent Form -->
    <form method="POST" action="submitconsent.php" enctype="multipart/form-data">
        <input type="hidden" name="org_id" value="<?php echo $org['id']; ?>" />

        <h3>Full Name</h3>
        <input type="text" name="name" value="<?php echo htmlspecialchars($studentName); ?>" readonly /><br>

        <h3>Registration Number</h3>
        <input type="text" name="regno" value="<?php echo htmlspecialchars($regno); ?>" readonly /><br>

        <h3>Batch</h3>
        <input type="text" name="batch" value="<?php echo htmlspecialchars($batch); ?>" readonly /><br>

        <h3>Priority for this Organization</h3>
        <select name="priority" required>
            <option value="1">First Choice</option>
            <option value="2">Second Choice</option>
            <option value="3">Third Choice</option>
        </select><br>

        <h3>GPA</h3>
        <input type="text" name="gpa" value="<?php echo htmlspecialchars($gpa); ?>" readonly /><br>

        <h3>Upload Your CV</h3>
        <input type="file" name="cv" required /><br>

        <button type="submit">Submit Consent</button>
    </form>
</div>

</body>
</html>
