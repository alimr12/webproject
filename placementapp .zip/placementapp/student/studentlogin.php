<!-- studentlogin.php -->

<?php
session_start();
include '../includes/db.php';

$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $regno = trim($_POST['regno']);
    $password = $_POST['password'];

    // Prepare statement to get user by regno
    $stmt = $conn->prepare("SELECT id, name, regno, password, role FROM users WHERE regno = ?");
    $stmt->bind_param("s", $regno);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($id, $name, $regno_db, $hashed_password, $role);

    if ($stmt->num_rows > 0) {
        $stmt->fetch();

        if ($role !== 'student') {
            $msg = "Access denied: Not a student account.";
        } elseif (password_verify($password, $hashed_password)) {
            // Set session variables
            $_SESSION['userid'] = $id;
            $_SESSION['name'] = $name;
            $_SESSION['regno'] = $regno_db;
            $_SESSION['role'] = $role;

            // Redirect to student dashboard
            header("Location: studentdashboard.php");
            exit();
        } else {
            $msg = "Invalid password.";
        }
    } else {
        $msg = "Student with this registration number not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Student Login - Placement App</title>
    <style>
        body {
            background: linear-gradient(to right, #28a745, #007bff); /* Green to Blue Gradient */
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
        }
        .login-box {
            width: 350px;
            margin: 120px auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            text-align: center;
        }
        h2 {
            margin-bottom: 25px;
            color: #333;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px;
            margin: 8px 0 16px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #218838;
        }
        .msg {
            color: red;
            margin-bottom: 15px;
        }
        .register-link {
            margin-top: 15px;
            font-size: 14px;
        }
        .register-link a {
            color: #0062cc;
            text-decoration: none;
        }
        .register-link a:hover {
            text-decoration: underline;
        }
        .forgot-password-link {
            margin-top: 15px;
            font-size: 14px;
        }
        .forgot-password-link a {
            color: #0062cc;
            text-decoration: none;
        }
        .forgot-password-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>Student Login</h2>

        <?php if ($msg): ?>
            <div class="msg"><?php echo htmlspecialchars($msg); ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <input type="text" name="regno" placeholder="Registration Number" required autofocus />
            <input type="password" name="password" placeholder="Password" required />
            <button type="submit">Login</button>
        </form>

        <div class="register-link">
            New student? <a href="../register.php">Register here</a>
        </div>

        <!-- Forgot Password Link -->
        <div class="forgot-password-link">
            <a href="forgotpassword.php">Forgot your password?</a>
        </div>
    </div>
</body>
</html>
