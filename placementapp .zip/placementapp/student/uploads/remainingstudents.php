<?php
session_start();
if (!isset($_SESSION['adminid'])) {
    header("Location: adminlogin.php");
    exit();
}

include '../includes/db.php';

// Fetch remaining students who have submitted consents but are not yet placed
$query = "
    SELECT u.userid, u.name, u.regno, u.gpa, u.batch, 
           GROUP_CONCAT(DISTINCT o.name ORDER BY c.priority) AS consented_orgs
    FROM consents c
    JOIN students u ON c.userid = u.userid
    JOIN organizations o ON c.orgid = o.id
    WHERE u.userid NOT IN (SELECT userid FROM finalplacements)
    GROUP BY u.userid
    ORDER BY u.gpa DESC
";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Unplaced Students</title>
    <style>
        body {
            background: linear-gradient(to right, #007bff, #28a745);
            font-family: Arial, sans-serif;
            color: #333;
            padding: 30px;
        }
        .container {
            background-color: #fff;
            border-radius: 14px;
            padding: 40px;
            max-width: 1100px;
            margin: auto;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ccc;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f3f3f3;
        }
        .btn {
            display: inline-block;
            padding: 10px 22px;
            background-color: #6c757d;
            color: white;
            font-size: 15px;
            text-decoration: none;
            border-radius: 6px;
            margin-top: 25px;
        }
        .btn:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Unplaced Students List</h2>

    <?php if ($result->num_rows > 0): ?>
        <table>
            <tr>
                <th>Name</th>
                <th>Reg No</th>
                <th>GPA</th>
                <th>Batch</th>
                <th>Consented Organizations</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['regno']) ?></td>
                    <td><?= htmlspecialchars($row['gpa']) ?></td>
                    <td><?= htmlspecialchars($row['batch']) ?></td>
                    <td><?= htmlspecialchars($row['consented_orgs']) ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p style="text-align:center;">🎉 All students are placed!</p>
    <?php endif; ?>

    <div style="text-align:center;">
        <a href="placementsummary.php" class="btn">⬅ Back to Summary</a>
    </div>
</div>

</body>
</html>
