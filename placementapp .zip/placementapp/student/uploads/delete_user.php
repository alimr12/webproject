<?php
// Include the database connection
include 'db_connection.php';

// Function to delete a user's data
function deleteUserData($user_id) {
    global $conn; // Use the global connection object

    // Start a transaction
    $conn->begin_transaction();

    try {
        // 1. Delete the user's history from the history table
        $deleteHistoryQuery = "DELETE FROM history WHERE user_id = ?";
        $stmt = $conn->prepare($deleteHistoryQuery);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();

        // 2. Delete the user's bookmarks from the bookmarks table
        $deleteBookmarksQuery = "DELETE FROM bookmarks WHERE user_id = ?";
        $stmt = $conn->prepare($deleteBookmarksQuery);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();

        // 3. Delete the user's personal information from the user table
        $deleteUserQuery = "DELETE FROM user WHERE user_id = ?";
        $stmt = $conn->prepare($deleteUserQuery);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();

        // Commit the transaction
        $conn->commit();

        echo "User data successfully deleted.<br>";

    } catch (Exception $e) {
        // If an error occurs, rollback the transaction to avoid partial deletion
        $conn->rollback();
        echo "Error: " . $e->getMessage() . "<br>";
    }
}

// Check if 'user_id' is passed in the URL
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id']; // Get user_id from the URL parameter
    deleteUserData($user_id); // Call the function to delete the user data
} else {
    echo "User ID is required.<br>";
}

// Close the database connection
$conn->close();
?>
