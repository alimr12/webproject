<?php
session_start();
if (!isset($_SESSION['adminid'])) {
    header("Location: adminlogin.php");
    exit();
}

include '../includes/db.php';

// Fetch placement data
$placementsQuery = "
    SELECT s.name AS student_name, s.regno, s.email, o.name AS org_name, p.batch, p.gpa
    FROM finalplacements fp
    JOIN users s ON fp.userid = s.id
    JOIN organizations o ON fp.orgid = o.id
    JOIN finalplacements p ON fp.userid = p.userid
    ORDER BY o.name, p.gpa DESC
";
$placementsResult = $conn->query($placementsQuery);

if (isset($_POST['download'])) {
    // Create an Excel file if the button is clicked

    // Set headers for the Excel file download
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="student_placements.xls"');
    header('Cache-Control: max-age=0');

    // Start writing the data in Excel format
    echo "Student Name\tReg No\tEmail\tOrganization Name\tBatch\tGPA\n";

    while ($row = $placementsResult->fetch_assoc()) {
        echo htmlspecialchars($row['student_name']) . "\t" .
             htmlspecialchars($row['regno']) . "\t" .
             htmlspecialchars($row['email']) . "\t" .
             htmlspecialchars($row['org_name']) . "\t" .
             htmlspecialchars($row['batch']) . "\t" .
             htmlspecialchars($row['gpa']) . "\n";
    }

    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Placements</title>
    <style>
        body {
            background: linear-gradient(to right, #007bff, #28a745);
            color: white;
            font-family: Arial, sans-serif;
            padding: 40px;
        }
        .container {
            background: white;
            color: #333;
            border-radius: 12px;
            padding: 30px;
            max-width: 1000px;
            margin: auto;
        }
        h2 {
            color: #007bff;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        th {
            background: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        .assign-btn {
            margin-top: 30px;
            padding: 12px 25px;
            background: #28a745;
            color: white;
            text-decoration: none;
            display: inline-block;
            border-radius: 8px;
            font-size: 16px;
        }
        .assign-btn:hover {
            background: #218838;
        }
        .back-btn {
            background-color: #6c757d;
            margin-left: 15px;
        }
        .download-btn {
            background-color: #ffc107;
            padding: 12px 25px;
            margin-top: 20px;
            font-size: 16px;
            text-decoration: none;
            color: white;
            border-radius: 8px;
        }
        .download-btn:hover {
            background: #d39e00;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Placement Overview</h2>

    <table>
        <tr>
            <th>Student Name</th>
            <th>Reg No</th>
            <th>Email</th>
            <th>Organization</th>
            <th>Batch</th>
            <th>GPA</th>
        </tr>
        <?php while ($row = $placementsResult->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['student_name']) ?></td>
                <td><?= htmlspecialchars($row['regno']) ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td><?= htmlspecialchars($row['org_name']) ?></td>
                <td><?= htmlspecialchars($row['batch']) ?></td>
                <td><?= htmlspecialchars($row['gpa']) ?></td>
            </tr>
        <?php endwhile; ?>
    </table>

    <div style="text-align:center;">
        <a href="assignplacement.php" class="assign-btn">📌 Assign Placements Now</a>
        <a href="admindashboard.php" class="assign-btn back-btn">⬅ Back to Dashboard</a>
        <form method="POST">
            <button type="submit" name="download" class="download-btn">Download Placements Excel</button>
        </form>
    </div>
</div>
</body>
</html>
