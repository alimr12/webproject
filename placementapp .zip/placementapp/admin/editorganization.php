<?php
session_start();
if (!isset($_SESSION['adminid'])) {
    header("Location: adminlogin.php");
    exit();
}

include '../includes/db.php';

$orgId = $_GET['orgid'] ?? null;
$message = '';

if (!$orgId) {
    die("Organization ID not provided.");
}

// Fetch existing data
$stmt = $conn->prepare("SELECT * FROM organizations WHERE id = ?");
$stmt->bind_param("i", $orgId);
$stmt->execute();
$result = $stmt->get_result();
$org = $result->fetch_assoc();

if (!$org) {
    die("Organization not found.");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $location = trim($_POST['location']);
    $domain = trim($_POST['domain']);
    $seats = intval($_POST['seats']);

    if ($name && $location && $domain && $seats > 0) {
        $updateStmt = $conn->prepare("UPDATE organizations SET name = ?, location = ?, domain = ?, seats = ? WHERE id = ?");
        $updateStmt->bind_param("sssii", $name, $location, $domain, $seats, $orgId);
        if ($updateStmt->execute()) {
            $message = "✅ Organization updated successfully.";
            // Refresh data
            $org = ['name' => $name, 'location' => $location, 'domain' => $domain, 'seats' => $seats];
        } else {
            $message = "❌ Failed to update.";
        }
    } else {
        $message = "⚠️ All fields are required and seats must be positive.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Edit Organization</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to right, #0a74da, #0056b3);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
        }
        .container {
            background: rgba(255, 255, 255, 0.97);
            color: #333;
            padding: 40px;
            border-radius: 14px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.25);
            max-width: 500px;
            width: 90%;
        }
        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 25px;
        }
        form input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        .btn {
            background-color: #ffc107;
            color: #333;
            font-size: 1.1rem;
            font-weight: bold;
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 8px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #e0a800;
        }
        .message {
            text-align: center;
            margin-top: 15px;
            font-weight: bold;
        }
        .back-btn {
            display: inline-block;
            margin-top: 20px;
            background-color: #6c757d;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 6px;
            text-align: center;
            width: 100%;
            box-sizing: border-box;
        }
        .back-btn:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit Organization</h2>
    <?php if ($message): ?>
        <div class="message"><?= $message ?></div>
    <?php endif; ?>
    <form method="POST">
        <input type="text" name="name" value="<?= htmlspecialchars($org['name']) ?>" placeholder="Organization Name" required>
        <input type="text" name="location" value="<?= htmlspecialchars($org['location']) ?>" placeholder="Location" required>
        <input type="text" name="domain" value="<?= htmlspecialchars($org['domain']) ?>" placeholder="Domain (e.g., IT, Health)" required>
        <input type="number" name="seats" value="<?= htmlspecialchars($org['seats']) ?>" placeholder="Available Seats" required min="1">
        <button type="submit" class="btn">💾 Update Organization</button>
    </form>
    <a href="vieworganizations.php" class="back-btn">⬅ Back to Organizations</a>
</div>

</body>
</html>
