<?php
session_start();
if (!isset($_SESSION['adminid'])) {
    header("Location: adminlogin.php");
    exit();
}

include '../includes/db.php';
define('CV_FOLDER', '../student/');

// Fetch consents with user and org info
$query = "
    SELECT c.*, u.name, u.regno, o.name AS org_name
    FROM consents c
    JOIN users u ON c.userid = u.id
    JOIN organizations o ON c.orgid = o.id
    ORDER BY c.userid, c.priority ASC
";
$consents = $conn->query($query);

// Fetch placed students
$placedMap = [];
$placedResult = $conn->query("SELECT userid, orgid FROM finalplacements");
while ($row = $placedResult->fetch_assoc()) {
    $placedMap[$row['userid']] = $row['orgid'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Consent Forms</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #28a745, #007bff); /* Green to Blue Gradient */
            margin: 0; padding: 0; color: #fff;
        }
        .container {
            margin: 40px auto;
            max-width: 1100px;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            color: #333;
        }
        h2 { text-align: center; color: #007bff; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ccc;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        .badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-weight: bold;
        }
        .placed { background: #28a745; color: white; }
        .inprocess { background: #ffc107; color: black; }
        .rejected { background: #dc3545; color: white; }
        .no-cv { color: red; font-weight: bold; }
        .button {
            background-color: #28a745;
            color: white;
            padding: 6px 12px;
            border-radius: 5px;
            text-decoration: none;
        }
        .button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Student Consent Forms</h2>
    <table>
        <thead>
        <tr>
            <th>Student Name</th>
            <th>Reg No</th>
            <th>Organization</th>
            <th>Priority</th>
            <th>Status</th>
            <th>CV</th>
        </tr>
        </thead>
        <tbody>
        <?php while ($row = $consents->fetch_assoc()):
            $userid = $row['userid'];
            $orgid = $row['orgid'];
            $cvPath = CV_FOLDER . $row['cv_path'];
            $webPath = '../student/' . $row['cv_path'];

            if (isset($placedMap[$userid]) && $placedMap[$userid] == $orgid) {
                $displayStatus = '<span class="badge placed">Placed</span>';
            } elseif ($row['status'] === 'inprocess') {
                $displayStatus = '<span class="badge inprocess">In Progress</span>';
            } else {
                $displayStatus = '<span class="badge rejected">Rejected</span>';
            }
        ?>
            <tr>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['regno']) ?></td>
                <td><?= htmlspecialchars($row['org_name']) ?></td>
                <td><?= htmlspecialchars($row['priority']) ?></td>
                <td><?= $displayStatus ?></td>
                <td>
                    <?php if (!empty($row['cv_path']) && file_exists($cvPath)): ?>
                        <a class="button" href="<?= $webPath ?>" download>View CV</a>
                    <?php else: ?>
                        <span class="no-cv">No CV available</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>
