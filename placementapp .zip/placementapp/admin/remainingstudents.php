<?php
session_start();
if (!isset($_SESSION['adminid'])) {
    header("Location: adminlogin.php");
    exit();
}

include '../includes/db.php';

// Fetch unplaced students (not in finalplacements)
$remainingQuery = "
    SELECT u.name, u.regno, s.gpa, s.batch
    FROM students s
    JOIN users u ON u.id = s.userid
    WHERE NOT EXISTS (
        SELECT 1 FROM finalplacements f WHERE f.userid = s.userid
    )
";
$remainingResult = $conn->query($remainingQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Unplaced Students</title>
    <style>
        body {
            background: linear-gradient(to right, #007bff, #28a745);
            font-family: Arial, sans-serif;
            color: #333;
            padding: 30px;
        }

        .container {
            background-color: #fff;
            border-radius: 14px;
            padding: 40px;
            max-width: 1000px;
            margin: auto;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }

        th, td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ccc;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f3f3f3;
        }

        .btn {
            display: inline-block;
            padding: 12px 24px;
            background-color: #28a745;
            color: white;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            border-radius: 6px;
            margin: 20px auto;
        }

        .btn:hover {
            background-color: #218838;
        }

        .back-btn {
            background-color: #6c757d;
        }

        .back-btn:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Unplaced Students</h2>

    <?php if ($remainingResult->num_rows > 0): ?>
        <table>
            <tr>
                <th>Name</th>
                <th>Reg No</th>
                <th>GPA</th>
                <th>Batch</th>
            </tr>
            <?php while ($row = $remainingResult->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['regno']) ?></td>
                    <td><?= htmlspecialchars($row['gpa']) ?></td>
                    <td><?= htmlspecialchars($row['batch']) ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p style="text-align:center;">✅ All students have been placed.</p>
    <?php endif; ?>

    <div style="text-align:center;">
        <a href="assignremaining.php" class="btn">📌 Assign Remaining Now</a>
        <a href="manageplacements.php" class="btn back-btn">⬅ Back to Dashboard</a>
    </div>
</div>

</body>
</html>
