<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['adminid'])) {
    header("Location: adminlogin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to right, #28a745, #007bff); /* Green to Blue Gradient */
            height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
        }
        .container {
            background: rgba(255, 255, 255, 0.12); /* Transparent White */
            padding: 60px 70px;
            border-radius: 18px;
            box-shadow: 0 10px 35px rgba(0, 0, 0, 0.25);
            text-align: center;
            max-width: 1200px;
            width: 100%;
        }
        h1 {
            font-weight: 700;
            font-size: 2.5rem;
            margin-bottom: 25px;
            letter-spacing: 1.8px;
        }
        h3 {
            font-size: 1.5rem;
            margin-bottom: 40px;
            font-weight: 500;
        }
        .btn-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            justify-items: center;
        }
        .btn {
            display: block;
            width: 90%;
            padding: 18px;
            margin: 12px 0;
            font-size: 1.4rem;
            font-weight: 700;
            border-radius: 12px;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
            text-decoration: none;
            color: white;
        }
        .btn:hover {
            opacity: 0.9;
        }
        .btn.view-students {
            background-color: #4CAF50;
        }
        .btn.view-students:hover {
            background-color: #45a049;
        }
        .btn.view-organizations {
            background-color: #008CBA;
        }
        .btn.view-organizations:hover {
            background-color: #007bb5;
        }
        .btn.assign-students {
            background-color: #f39c12;
        }
        .btn.assign-students:hover {
            background-color: #e67e22;
        }
        .btn.view-consent {
            background-color: #3498db;
        }
        .btn.view-consent:hover {
            background-color: #2980b9;
        }
        .btn.logout {
            background-color: #e74c3c;
        }
        .btn.logout:hover {
            background-color: #c0392b;
        }

        @media (max-width: 768px) {
            .btn-container {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        @media (max-width: 480px) {
            .btn-container {
                grid-template-columns: 1fr;
            }
            h1 {
                font-size: 2rem;
            }
            .btn {
                font-size: 1.1rem;
                padding: 14px 0;
            }
        }
    </style>
</head>
<body>

<div class="container" role="main" aria-label="Admin Dashboard">
    <h1>Welcome, Admin</h1>
    <h3>Choose an action below:</h3>

    <!-- Admin Options with Big Buttons -->
    <div class="btn-container">
        <a href="viewstudents.php" class="btn view-students" role="button">View All Students</a>
        <a href="vieworganizations.php" class="btn view-organizations" role="button">View All Organizations</a>
        <a href="manageplacements.php" class="btn assign-students" role="button">Manage Placements</a>
        
        <a href="viewconsents.php" class="btn view-consent" role="button">View Consent Forms</a>
        <a href="remainingstudents.php" class="btn assign-students" role="button">Assign Remaining Students</a>
        <a href="logout.php" class="btn logout" role="button">Logout</a>
    </div>
</div>

</body>
</html>
