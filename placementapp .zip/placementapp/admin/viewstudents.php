<?php
session_start();
if (!isset($_SESSION['adminid'])) {
    header("Location: adminlogin.php");
    exit();
}

include '../includes/db.php';

// Fetch placed students
$query = "
    SELECT u.id, u.name, u.regno, u.email,
        IF(fp.userid IS NOT NULL, 'placed',
            (SELECT c.status FROM consents c WHERE c.userid = u.id ORDER BY c.id DESC LIMIT 1)
        ) AS placement_status
    FROM users u
    LEFT JOIN finalplacements fp ON u.id = fp.userid
    WHERE u.role = 'student'
";
$students = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>All Students</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to right, #28a745, #007bff); /* Green to Blue Gradient */
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: start;
            color: white;
        }
        .container {
            margin: 50px auto;
            background: rgba(255, 255, 255, 0.97); /* Transparent White */
            color: #333;
            padding: 40px;
            border-radius: 14px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.25);
            max-width: 1000px;
            width: 90%;
        }
        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
            font-size: 15px;
        }
        th {
            background-color: #007bff;
            color: white;
            font-size: 16px;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:nth-child(odd) {
            background-color: #eef3fb;
        }
        .badge {
            display: inline-block;
            padding: 6px 12px;
            font-size: 13px;
            font-weight: bold;
            border-radius: 20px;
            color: white;
        }
        .placed {
            background-color: #28a745; /* Green */
        }
        .inprocess {
            background-color: #ffc107; /* Yellow */
            color: black;
        }
        .unknown {
            background-color: #6c757d; /* Grey */
        }
        .back-btn {
            display: inline-block;
            margin-top: 30px;
            background-color: #6c757d;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 6px;
        }
        .back-btn:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>All Students</h2>

    <table>
        <tr>
            <th>Student Name</th>
            <th>Reg No</th>
            <th>Email</th>
            <th>Placement Status</th>
        </tr>
        <?php while ($student = $students->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($student['name']) ?></td>
            <td><?= htmlspecialchars($student['regno']) ?></td>
            <td><?= htmlspecialchars($student['email']) ?></td>
            <td>
                <?php
                    $status = $student['placement_status'];
                    if ($status === 'placed') {
                        echo '<span class="badge placed">Placed</span>';
                    } elseif ($status === 'inprocess') {
                        echo '<span class="badge inprocess">In Progress</span>';
                    } elseif (!empty($status)) {
                        echo '<span class="badge unknown">' . htmlspecialchars(ucfirst($status)) . '</span>';
                    } else {
                        echo '<span class="badge unknown">No Status</span>';
                    }
                ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

    <div style="text-align: center;">
        <a href="admindashboard.php" class="back-btn">⬅ Back to Dashboard</a>
    </div>
</div>

</body>
</html>
