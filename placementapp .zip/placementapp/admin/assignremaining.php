<?php
session_start();
if (!isset($_SESSION['adminid'])) {
    header("Location: adminlogin.php");
    exit();
}

include '../includes/db.php';

// STEP 1: Fetch remaining consents with student info
$remainingConsents = $conn->query("
    SELECT c.*, s.gpa, s.batch, u.regno, u.name, o.seats, o.id as orgid, o.name as org_name
    FROM consents c
    JOIN students s ON c.userid = s.userid
    JOIN users u ON c.userid = u.id
    JOIN organizations o ON c.orgid = o.id
    WHERE c.status = 'inprocess'
    AND NOT EXISTS (
        SELECT 1 FROM finalplacements f WHERE f.userid = c.userid
    )
    ORDER BY c.priority ASC, s.gpa DESC
");

$messages = [];

while ($row = $remainingConsents->fetch_assoc()) {
    $userid = $row['userid'];
    $orgid = $row['orgid'];
    $batch = $row['batch'];
    $regno = $row['regno'];
    $gpa = $row['gpa'];
    $orgName = $row['org_name'];
    $studentName = $row['name'];

    // Check already placed again (precaution)
    $alreadyPlaced = $conn->query("SELECT * FROM finalplacements WHERE userid = $userid")->num_rows;
    if ($alreadyPlaced > 0) continue;

    // Check seat availability in the selected organization
    $placedCount = $conn->query("SELECT COUNT(*) FROM finalplacements WHERE orgid = $orgid")->fetch_row()[0];
    $seatLimit = $row['seats'];

    if ($placedCount < $seatLimit) {
        // Place student in the current organization
        $stmt = $conn->prepare("INSERT INTO finalplacements (userid, orgid, batch, regno, gpa) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iiisd", $userid, $orgid, $batch, $regno, $gpa);
        if ($stmt->execute()) {
            // Update consent status to 'placed'
            $conn->query("UPDATE consents SET status = 'placed' WHERE userid = $userid AND orgid = $orgid");
            $messages[] = "✅ Placed <b>$studentName</b> in <b>$orgName</b>.";
        }
    } else {
        // No seats left, mark the student as rejected
        $status = 'rejected';
        $conn->query("UPDATE consents SET status = 'rejected' WHERE userid = $userid AND orgid = $orgid");

        // Automatically place the student in another organization with available seats
        $availableOrgQuery = $conn->query("SELECT * FROM organizations WHERE id != $orgid AND id NOT IN (SELECT orgid FROM finalplacements WHERE userid = $userid) LIMIT 1");
        if ($availableOrg = $availableOrgQuery->fetch_assoc()) {
            $newOrgid = $availableOrg['id'];
            $newOrgName = $availableOrg['name'];
            $newSeatCount = $availableOrg['seats'];

            // Place student in the available organization
            $stmt = $conn->prepare("INSERT INTO finalplacements (userid, orgid, batch, regno, gpa) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("iiisd", $userid, $newOrgid, $batch, $regno, $gpa);
            if ($stmt->execute()) {
                // Update consent status to 'placed' in new organization
                $conn->query("UPDATE consents SET status = 'placed' WHERE userid = $userid AND orgid = $newOrgid");
                $messages[] = "✅ No seat left for <b>$studentName</b> in <b>$orgName</b>, but they were automatically placed in <b>$newOrgName</b>.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Assign Remaining Students</title>
    <style>
        body {
            background: linear-gradient(to right, #007bff, #28a745);
            font-family: Arial, sans-serif;
            padding: 30px;
            color: white;
        }

        .container {
            background-color: #fff;
            color: #333;
            border-radius: 12px;
            padding: 30px;
            max-width: 900px;
            margin: auto;
            box-shadow: 0 0 20px rgba(0,0,0,0.25);
        }

        h2 {
            color: #007bff;
            text-align: center;
        }

        ul {
            line-height: 1.8;
            margin-top: 20px;
        }

        li {
            margin-bottom: 8px;
        }

        .btn {
            display: inline-block;
            padding: 12px 24px;
            background-color: #28a745;
            color: white;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            border-radius: 6px;
            margin: 30px auto;
            text-align: center;
        }

        .btn:hover {
            background-color: #218838;
        }

        .back-btn {
            background-color: #6c757d;
        }

        .back-btn:hover {
            background-color: #5a6268;
        }

        .btn-wrapper {
            text-align: center;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Remaining Students Assignment Result</h2>
    <ul>
        <?php if (!empty($messages)): ?>
            <?php foreach ($messages as $msg): ?>
                <li><?= $msg ?></li>
            <?php endforeach; ?>
        <?php else: ?>
            <li>🎓 No remaining students to assign.</li>
        <?php endif; ?>
    </ul>

    <div class="btn-wrapper">
        <a href="remainingstudents.php" class="btn">🔄 View Remaining Students</a>
        <a href="manageplacements.php" class="btn back-btn">⬅ Back to Dashboard</a>
    </div>
</div>
</body>
</html>
