<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include '../includes/db.php';

    // Get admin credentials from form
    $adminUsername = $_POST['username'];
    $adminPassword = $_POST['password'];

    // Query the database to verify admin credentials (using plain text password)
    $stmt = $conn->prepare("SELECT id, username, password FROM admins WHERE username = ?");
    $stmt->bind_param("s", $adminUsername);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();
        // Directly compare the entered password with the stored password
        if ($adminPassword === $admin['password']) {
            // Set session and redirect to admin dashboard
            $_SESSION['adminid'] = $admin['id'];
            $_SESSION['adminusername'] = $admin['username'];
            header("Location: admindashboard.php"); // Redirect to the correct dashboard
            exit();
        } else {
            $error = "Invalid credentials.";
        }
    } else {
        $error = "Invalid credentials.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <style>
        /* General body styling */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to right, #28a745, #007bff); /* Green to Blue Gradient */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        /* Container for login form */
        .login-container {
            width: 400px;
            padding: 40px;
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        .login-container h2 {
            margin-bottom: 30px;
            color: #333;
        }

        .input-field {
            width: 100%;
            padding: 14px;
            margin: 12px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 16px;
            background-color: #f8f8f8;
            transition: all 0.3s ease;
        }

        .input-field:focus {
            border-color: #28a745;
            background-color: #e9ffe6;
            outline: none;
        }

        .submit-btn {
            width: 100%;
            padding: 14px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #218838;
        }

        .error {
            color: red;
            margin-bottom: 10px;
            font-size: 14px;
        }

        .footer {
            margin-top: 20px;
            font-size: 14px;
        }

        .footer a {
            color: #007bff;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>Admin Login</h2>

    <!-- Error message display -->
    <?php if (isset($error)): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST" action="adminlogin.php">
        <input type="text" name="username" class="input-field" placeholder="Admin Username" required>
        <input type="password" name="password" class="input-field" placeholder="Password" required>
        <button type="submit" class="submit-btn">Login</button>
    </form>

    <div class="footer">
        <!-- New admin register link -->
        <p>Contact: <a href="http://www.fui.edu.pk" target="_blank">FUI Website</a></p>
    </div>
</div>

</body>
</html>
