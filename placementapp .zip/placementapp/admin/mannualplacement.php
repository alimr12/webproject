<?php
session_start();
if (!isset($_SESSION['adminid'])) {
    header("Location: adminlogin.php");
    exit();
}
include '../includes/db.php';

// Count how many students are placed
$countResult = $conn->query("SELECT COUNT(*) FROM finalplacements");
$placedCount = $countResult->fetch_row()[0];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Placements</title>
    <style>
        body {
            background: linear-gradient(to right, #007bff, #0056b3);
            color: white;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            background: white;
            color: #333;
            max-width: 600px;
            margin: 80px auto;
            padding: 40px;
            border-radius: 14px;
            text-align: center;
        }
        h2 {
            color: #007bff;
            font-size: 2.2rem;
        }
        .btn {
            padding: 15px 25px;
            font-size: 1.1rem;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            margin: 15px;
            cursor: pointer;
            text-decoration: none;
        }
        .btn-place {
            background-color: #28a745;
            color: white;
        }
        .btn-place:hover {
            background-color: #218838;
        }
        .btn-back {
            background-color: #6c757d;
            color: white;
        }
        .btn-back:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Manage Placements</h2>
    <p>Total Students Placed: <strong><?= $placedCount ?></strong></p>

    <a href="assignplacement.php" class="btn btn-place">📌 Place a Student</a>
    <a href="admindashboard.php" class="btn btn-back">⬅️ Back to Dashboard</a>
</div>

</body>
</html>
