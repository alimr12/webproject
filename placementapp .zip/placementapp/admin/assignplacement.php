<?php
session_start();
if (!isset($_SESSION['adminid'])) {
    header("Location: adminlogin.php");
    exit();
}

include '../includes/db.php';

// Fetch placed students
$placedQuery = "
    SELECT f.id, u.name AS student_name, u.regno, o.name AS organization_name
    FROM finalplacements f
    JOIN users u ON f.userid = u.id
    JOIN organizations o ON f.orgid = o.id
    ORDER BY f.id ASC
";
$placedResult = $conn->query($placedQuery);

// Stats
$totalConsents = $conn->query("SELECT COUNT(*) FROM consents")->fetch_row()[0];
$totalPlaced = $conn->query("SELECT COUNT(*) FROM finalplacements")->fetch_row()[0];
$totalRemaining = $totalConsents - $totalPlaced;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Placement Assignment Summary</title>
    <style>
        body {
            background: linear-gradient(to right, #28a745, #007bff);
            font-family: Arial, sans-serif;
            color: #333;
            padding: 30px;
        }
        .container {
            background-color: #fff;
            border-radius: 14px;
            padding: 40px;
            max-width: 1000px;
            margin: auto;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
        }
        .stats {
            text-align: center;
            margin-bottom: 30px;
        }
        .stats p {
            font-size: 18px;
            margin: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        th, td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ccc;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f3f3f3;
        }
        .btn {
            display: inline-block;
            padding: 12px 24px;
            background-color: #28a745;
            color: white;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            border-radius: 6px;
            margin: 20px auto;
        }
        .btn:hover {
            background-color: #218838;
        }
        .back-btn {
            background-color: #6c757d;
        }
        .back-btn:hover {
            background-color: #5a6268;
        }
        .logic-section {
            background-color: #f8f9fa;
            padding: 25px;
            border-radius: 10px;
            margin-top: 30px;
        }
        .logic-section h4 {
            color: #007bff;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Placement Assignment Summary</h2>

    <div class="stats">
        <p><strong>Total Consents Submitted:</strong> <?= $totalConsents ?></p>
        <p><strong>Total Students Placed:</strong> <?= $totalPlaced ?></p>
        <p><strong>Remaining Students:</strong> <?= $totalRemaining ?></p>
    </div>

    <?php if ($placedResult->num_rows > 0): ?>
        <table>
            <tr>
                <th>Student Name</th>
                <th>Reg No</th>
                <th>Assigned Organization</th>
            </tr>
            <?php while ($row = $placedResult->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['student_name']) ?></td>
                    <td><?= htmlspecialchars($row['regno']) ?></td>
                    <td><?= htmlspecialchars($row['organization_name']) ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p style="text-align: center;">No students have been placed yet.</p>
    <?php endif; ?>

    <div style="text-align: center;">
	<a href="remainingstudents.php" class="btn">📌 View Remaining Students</a>
        <a href="manageplacements.php" class="btn back-btn">⬅ Back to Placement Dashboard</a>
    </div>

    <div class="logic-section">
        <h4>📊 Placement Logic Summary</h4>
        <p>The placement system uses the following logic to ensure fair and optimal seat allocation:</p>
        <ul>
            <li>🎓 Students submit up to 3 prioritized consent applications to organizations.</li>
            <li>📌 When assigning placements:
                <ul>
                    <li>Priority 1 applications are considered first, followed by Priority 2 and 3.</li>
                    <li>Within each priority, students with higher GPAs are preferred.</li>
                </ul>
            </li>
            <li>🔁 If an organization has limited seats, only the top students (by GPA) matching the priority are placed.</li>
            <li>✅ Placed students are skipped in further rounds to avoid duplication.</li>
            <li>📉 Remaining students are displayed for manual or later placement.</li>
        </ul>
    </div>
</div>

</body>
</html>
