<?php
session_start();
if (!isset($_SESSION['adminid'])) {
    header("Location: adminlogin.php");
    exit();
}

include '../includes/db.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $location = trim($_POST['location']);
    $domain = trim($_POST['domain']);
    $seats = intval($_POST['seats']);

    if ($name && $location && $domain && $seats > 0) {
        $stmt = $conn->prepare("INSERT INTO organizations (name, location, domain, seats) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $name, $location, $domain, $seats);
        if ($stmt->execute()) {
            $message = "✅ Organization added successfully.";
        } else {
            $message = "❌ Error: Could not add organization.";
        }
    } else {
        $message = "⚠️ All fields are required and seats must be a positive number.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Add New Organization</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to right, #0a74da, #0056b3);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
        }
        .container {
            background: rgba(255, 255, 255, 0.95);
            color: #333;
            padding: 40px;
            border-radius: 14px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.25);
            max-width: 500px;
            width: 90%;
        }
        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 25px;
        }
        form input, form select {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        .btn {
            background-color: #28a745;
            color: white;
            font-size: 1.1rem;
            font-weight: bold;
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 8px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #218838;
        }
        .message {
            text-align: center;
            margin-top: 15px;
            font-weight: bold;
        }
        .back-btn {
            display: inline-block;
            margin-top: 20px;
            background-color: #6c757d;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 6px;
        }
        .back-btn:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Add New Organization</h2>
    <?php if ($message): ?>
        <div class="message"><?= $message ?></div>
    <?php endif; ?>
    <form method="POST">
        <input type="text" name="name" placeholder="Organization Name" required>
        <input type="text" name="location" placeholder="Location" required>
        <input type="text" name="domain" placeholder="Domain (e.g., IT, Health)" required>
        <input type="number" name="seats" placeholder="Available Seats" required min="1">
        <button type="submit" class="btn">➕ Add Organization</button>
    </form>
    <div style="text-align: center;">
        <a href="vieworganizations.php" class="back-btn">⬅ Back to Organizations</a>
    </div>
</div>

</body>
</html>
