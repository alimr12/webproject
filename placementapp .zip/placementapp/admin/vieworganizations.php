<?php
session_start();
if (!isset($_SESSION['adminid'])) {
    header("Location: adminlogin.php");
    exit();
}

include '../includes/db.php';

// Fetch all organizations with count of placed students
$query = "
    SELECT o.id, o.name, o.location, o.domain, o.seats,
           (SELECT COUNT(*) FROM finalplacements f WHERE f.orgid = o.id) AS placed_count
    FROM organizations o
";
$organizations = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>All Organizations</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to right, #28a745, #007bff); /* Green to Blue Gradient */
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: start;
            color: white;
        }
        .container {
            margin: 50px auto;
            background: rgba(255, 255, 255, 0.97);
            color: #333;
            padding: 40px;
            border-radius: 14px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.25);
            max-width: 1000px;
            width: 90%;
        }
        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
            font-size: 15px;
        }
        th {
            background-color: #007bff;
            color: white;
            font-size: 16px;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:nth-child(odd) {
            background-color: #eef3fb;
        }
        .actions a {
            display: inline-block;
            margin: 4px;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: bold;
            transition: background 0.3s;
        }
        .view-btn { background-color: #17a2b8; color: white; }
        .edit-btn { background-color: #ffc107; color: #222; }
        .delete-btn { background-color: #dc3545; color: white; }

        .view-btn:hover { background-color: #138496; }
        .edit-btn:hover { background-color: #e0a800; }
        .delete-btn:hover { background-color: #c82333; }

        .back-btn, .add-btn {
            display: inline-block;
            margin-top: 30px;
            margin-right: 10px;
            background-color: #6c757d;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 6px;
        }
        .back-btn:hover, .add-btn:hover { background-color: #5a6268; }
        .add-btn { background-color: #28a745; }
        .add-btn:hover { background-color: #218838; }
    </style>
</head>
<body>

<div class="container">
    <h2>All Organizations (Real-Time Seats)</h2>

    <table>
        <tr>
            <th>Name</th>
            <th>Location</th>
            <th>Domain</th>
            <th>Total Seats</th>
            <th>Placed</th>
            <th>Remaining</th>
            <th>Actions</th>
        </tr>

        <?php while ($org = $organizations->fetch_assoc()): 
            $remaining = $org['seats'] - $org['placed_count'];
        ?>
        <tr>
            <td><?= htmlspecialchars($org['name']) ?></td>
            <td><?= htmlspecialchars($org['location']) ?></td>
            <td><?= htmlspecialchars($org['domain']) ?></td>
            <td><?= $org['seats'] ?></td>
            <td><?= $org['placed_count'] ?></td>
            <td><?= $remaining > 0 ? $remaining : "<span style='color:red;'>0 (Full)</span>" ?></td>
            <td class="actions">
                <a class="view-btn" href="vieworganization.php?orgid=<?= $org['id'] ?>">View</a>
                <a class="edit-btn" href="editorganization.php?orgid=<?= $org['id'] ?>">Edit</a>
                <a class="delete-btn" href="deleteorganization.php?orgid=<?= $org['id'] ?>" onclick="return confirm('Are you sure you want to delete this organization?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

    <div style="text-align: center;">
        <a href="admindashboard.php" class="back-btn">⬅ Back to Dashboard</a>
        <a href="addorganization.php" class="add-btn">➕ Add New Organization</a>
    </div>
</div>

</body>
</html>
