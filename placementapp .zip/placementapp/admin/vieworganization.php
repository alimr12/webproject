<?php
session_start();
if (!isset($_SESSION['adminid'])) {
    header("Location: adminlogin.php");
    exit();
}

include '../includes/db.php';

$orgId = $_GET['orgid'] ?? null;
if (!$orgId) {
    die("⚠️ Organization ID not provided.");
}

$stmt = $conn->prepare("SELECT * FROM organizations WHERE id = ?");
$stmt->bind_param("i", $orgId);
$stmt->execute();
$result = $stmt->get_result();
$org = $result->fetch_assoc();

if (!$org) {
    die("❌ Organization not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Organization Details</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0a74da, #0056b3);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
        }
        .container {
            background: rgba(255, 255, 255, 0.97);
            color: #333;
            padding: 40px;
            border-radius: 14px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.25);
            max-width: 500px;
            width: 90%;
        }
        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 25px;
        }
        .info {
            margin: 15px 0;
            font-size: 18px;
        }
        .info span {
            font-weight: bold;
            color: #0056b3;
        }
        .back-btn {
            display: block;
            margin-top: 30px;
            text-align: center;
            background-color: #6c757d;
            color: white;
            padding: 12px;
            text-decoration: none;
            border-radius: 8px;
        }
        .back-btn:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Organization Details</h2>
    <div class="info"><span>Name:</span> <?= htmlspecialchars($org['name']) ?></div>
    <div class="info"><span>Location:</span> <?= htmlspecialchars($org['location']) ?></div>
    <div class="info"><span>Domain:</span> <?= htmlspecialchars($org['domain']) ?></div>
    <div class="info"><span>Available Seats:</span> <?= htmlspecialchars($org['seats']) ?></div>

    <a href="vieworganizations.php" class="back-btn">⬅ Back to Organizations</a>
</div>

</body>
</html>
