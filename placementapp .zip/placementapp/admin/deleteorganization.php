<?php
session_start();
if (!isset($_SESSION['adminid'])) {
    header("Location: adminlogin.php");
    exit();
}

include '../includes/db.php';

if (!isset($_GET['orgid'])) {
    echo "Organization ID missing.";
    exit();
}

$orgid = intval($_GET['orgid']);
$stmt = $conn->prepare("DELETE FROM organizations WHERE id = ?");
$stmt->bind_param("i", $orgid);

if ($stmt->execute()) {
    header("Location: vieworganizations.php?deleted=1");
    exit();
} else {
    echo "Error deleting organization.";
}
?>
