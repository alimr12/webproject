<?php
$host = 'localhost';
$user = 'root';        // use your MySQL username
$pass = '';            // use your MySQL password ('' if none)
$dbname = 'placementapp';

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
