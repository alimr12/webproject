<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>SIT Placement Portal</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0a74da, #0056b3);
            margin: 0;
            padding: 0;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }

        /* University Logo */
        .logo {
            position: fixed;
            top: 20px;
            left: 20px;
            width: 120px; /* Adjust size as needed */
            z-index: 10;  /* Ensures the logo stays on top */
            background-color: #003366; /* Background color of the navbar */
            padding: 10px;  /* Padding to make it more aligned */
            border-radius: 8px; /* Optional to round the edges */
        }

        .hero-section {
            text-align: center;
            padding: 50px 20px;
            max-width: 800px;
            width: 90%;
            margin: 30px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 18px;
            box-shadow: 0px 0px 30px rgba(0, 0, 0, 0.2);
        }

        h1 {
            font-size: 3rem;
            font-weight: bold;
            color: #fff;
            margin-bottom: 20px;
        }

        p {
            font-size: 1.2rem;
            margin-bottom: 30px;
            color: #ddd;
        }

        .btn {
            display: inline-block;
            padding: 16px 30px;
            margin: 10px;
            font-size: 1.2rem;
            font-weight: 700;
            color: white;
            text-decoration: none;
            background-color: #28a745;
            border-radius: 10px;
            transition: background-color 0.3s ease;
        }

        .btn.admin {
            background-color: #ffc107;
        }

        .btn:hover {
            background-color: #218838;
        }

        .btn.admin:hover {
            background-color: #d39e00;
        }

        .stats-section {
            width: 100%;
            background-color: #fff;
            color: #333;
            text-align: center;
            padding: 40px;
            margin-top: 30px;
            border-radius: 18px;
            box-shadow: 0px 0px 30px rgba(0, 0, 0, 0.2);
        }

        .stats-section h2 {
            font-size: 2.5rem;
            margin-bottom: 20px;
            color: #0a74da;
        }

        .stats {
            display: flex;
            justify-content: space-around;
            text-align: center;
        }

        .stat-item {
            font-size: 1.5rem;
            margin-top: 20px;
        }

        .stat-item span {
            display: block;
            font-weight: bold;
            font-size: 2rem;
            margin-bottom: 5px;
        }

        .footer {
            margin-top: 40px;
            font-size: 1.2rem;
            color: #ddd;
        }
    </style>
</head>
<body>

<!-- University Logo -->
<img src="assets/3.png" alt="University Logo" class="logo">

<div class="hero-section">
    <h1>Welcome to SIT Placement Portal</h1>
    <p>Efficiently manage and track student placements, keep up with upcoming company drives, and manage the placement process effectively!</p>
    <a href="student/studentlogin.php" class="btn">Student Login</a>
    <a href="admin/adminlogin.php" class="btn admin">Admin Login</a>
</div>

<div class="stats-section">
    <h2>Placement Statistics</h2>
    <div class="stats">
        <div class="stat-item">
            <span>100+</span>
            <p>Companies Registered</p>
        </div>
        <div class="stat-item">
            <span>200+</span>
            <p>Students Placed</p>
        </div>
        <div class="stat-item">
            <span>50+</span>
            <p>Applications Sent</p>
        </div>
    </div>
</div>

<div class="footer">
    <p>All rights reserved &copy; 2025 Placement Portal | Developed by SIT</p>
</div>

</body>
</html>
