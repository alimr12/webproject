-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2025 at 07:55 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `placementapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'admin', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `consents`
--

CREATE TABLE `consents` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `orgid` int(11) NOT NULL,
  `cv_path` varchar(255) DEFAULT NULL,
  `gpa` decimal(3,2) DEFAULT NULL,
  `batch` varchar(50) DEFAULT NULL,
  `status` enum('inprocess','approved') DEFAULT 'inprocess',
  `consent_date` datetime DEFAULT current_timestamp(),
  `priority` int(11) NOT NULL,
  `regno` varchar(50) NOT NULL,
  `cv` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `consents`
--

INSERT INTO `consents` (`id`, `userid`, `orgid`, `cv_path`, `gpa`, `batch`, `status`, `consent_date`, `priority`, `regno`, `cv`) VALUES
(1, 2, 1, 'uploads/Formatted_Automation_in_Modern_Manufacturing_Report.docx', 4.50, '2022', 'inprocess', '2025-05-24 04:04:40', 1, '026', NULL),
(2, 2, 2, 'uploads/Automation_in_Modern_Manufacturing_Report.docx', 4.50, '2022', 'inprocess', '2025-05-24 04:05:13', 2, '026', NULL),
(3, 2, 3, 'uploads/Automation_in_Modern_Manufacturing_Report.docx', 4.50, '2022', '', '2025-05-24 04:05:21', 1, '026', NULL),
(5, 3, 1, 'Page_Replacement_Algorithms.docx', 2.00, '2023', 'inprocess', '2025-05-25 02:56:00', 3, '002', NULL),
(6, 3, 2, 'This is a copy of a conversation between ChatGPT.docx', 2.00, '2023', '', '2025-05-25 03:34:58', 1, '002', NULL),
(7, 3, 3, 'Fee Challan.pdf', 2.00, '2023', 'inprocess', '2025-05-25 03:40:59', 2, '002', NULL),
(8, 4, 1, NULL, 8.00, '2025', 'inprocess', '2025-05-25 03:58:16', 2, '056', 'Page_Replacement_Algorithms.docx'),
(9, 4, 2, 'full_chat_history.docx', 8.00, '2025', 'inprocess', '2025-05-25 04:08:25', 3, '056', NULL),
(10, 4, 3, NULL, NULL, NULL, '', '2025-05-25 04:58:53', 1, '', '68325d3dd572c4.11169736.docx'),
(11, 4, 3, NULL, NULL, NULL, '', '2025-05-25 04:59:17', 1, '', '68325d55ef2596.44166587.docx'),
(12, 4, 3, NULL, NULL, NULL, '', '2025-05-25 04:59:47', 1, '', '68325d73eb5899.51795371.docx'),
(13, 5, 3, 'uploads/chat_history.docx', 8.00, '2025', '', '2025-05-25 05:18:14', 1, '056', NULL),
(14, 5, 2, 'uploads/Page_Replacement_Algorithms (1).docx', 3.00, '2015', 'inprocess', '2025-05-25 05:31:00', 1, '033', NULL),
(15, 5, 1, 'uploads/HI (1).docx', 3.00, '2015', 'inprocess', '2025-05-25 11:14:32', 1, '033', NULL),
(16, 2, 4, 'uploads/letter (1).pdf', 4.50, '2022', 'inprocess', '2025-05-25 15:16:37', 3, '026', NULL),
(17, 6, 1, 'uploads/IWT Lab Report Frontpage Temp (2).docx', 4.00, '2024', 'inprocess', '2025-05-27 04:17:31', 2, '015', NULL),
(18, 6, 2, 'uploads/student_placements (1).xls', 4.00, '2024', 'inprocess', '2025-05-27 04:36:20', 1, '015', NULL),
(19, 6, 3, 'uploads/chat_history.docx', 4.00, '2024', 'inprocess', '2025-05-27 04:36:36', 3, '015', NULL),
(20, 7, 1, 'uploads/IWT Lab Report Frontpage Temp (2).docx', 3.40, '1969', '', '2025-05-27 04:39:21', 1, '010', NULL),
(21, 7, 2, 'uploads/Formatted_Automation_in_Modern_Manufacturing_Report.docx', 3.40, '1969', 'inprocess', '2025-05-27 04:39:35', 2, '010', NULL),
(22, 7, 3, 'uploads/letter (3).pdf', 3.40, '1969', 'inprocess', '2025-05-27 04:39:47', 3, '010', NULL),
(23, 8, 1, 'uploads/student_placements (1).xls', 4.00, '2023', '', '2025-05-28 15:02:21', 1, '005', NULL),
(24, 8, 2, 'uploads/Wajih Awais Jafri .docx', 4.00, '2023', '', '2025-05-28 15:02:30', 1, '005', NULL),
(25, 8, 4, 'uploads/phpMyAdmin-5.2.2-all-languages.zip', 4.00, '2023', '', '2025-05-28 15:02:43', 1, '005', NULL),
(26, 8, 5, 'uploads/letter.pdf', 4.00, '2023', '', '2025-05-28 15:06:21', 3, '005', NULL),
(27, 9, 4, 'uploads/remainingstudents.php', 3.80, '2021', 'inprocess', '2025-05-28 15:13:14', 3, '99', NULL),
(28, 9, 2, 'uploads/remainingstudents.php', 3.80, '2021', '', '2025-05-28 15:13:27', 1, '99', NULL),
(29, 9, 1, 'uploads/remainingstudents.php', 3.80, '2021', 'inprocess', '2025-05-28 15:13:40', 3, '99', NULL),
(30, 10, 5, 'uploads/Delete_User_Data_PHP_Code.docx', 4.00, '2019', '', '2025-05-28 15:52:14', 1, '112', NULL),
(31, 10, 4, 'uploads/remainingstudents.php', 4.00, '2019', 'inprocess', '2025-05-28 15:52:48', 2, '112', NULL),
(32, 10, 3, 'uploads/Delete_User_Data_PHP_Code.docx', 4.00, '2019', 'inprocess', '2025-05-28 15:52:59', 3, '112', NULL),
(33, 10, 1, 'uploads/remainingstudents.php', 4.00, '2019', 'inprocess', '2025-05-28 16:23:24', 1, '112', NULL),
(34, 11, 5, 'uploads/IWT Lab Report Frontpage Temp (2).docx', 3.70, '2012', '', '2025-05-28 16:26:40', 1, '2060', NULL),
(35, 12, 2, 'uploads/IWT Lab Report Frontpage Temp (1).docx', 4.00, '2019', 'inprocess', '2025-05-29 00:46:57', 1, '25', NULL),
(36, 12, 3, 'uploads/remainingstudents.php', 4.00, '2019', 'inprocess', '2025-05-29 00:47:07', 2, '25', NULL),
(37, 12, 1, 'uploads/Delete_User_Data_PHP_Code.docx', 4.00, '2019', '', '2025-05-29 00:47:14', 1, '25', NULL),
(38, 13, 1, 'uploads/student_placements (3).xls', 2.90, '2021', '', '2025-05-29 01:05:08', 1, '333', NULL),
(39, 13, 2, 'uploads/This is a copy of a conversation between ChatGPT.docx', 2.90, '2021', 'inprocess', '2025-05-29 01:05:21', 3, '333', NULL),
(40, 13, 4, 'uploads/LAB NO2 WEB (1).docx', 2.90, '2021', 'inprocess', '2025-05-29 01:05:32', 2, '333', NULL),
(41, 14, 1, 'uploads/index.php', 3.80, '2015', '', '2025-05-29 03:12:15', 1, '222', NULL),
(42, 14, 2, 'uploads/delete_user.php', 3.80, '2015', 'inprocess', '2025-05-29 03:12:28', 2, '222', NULL),
(43, 14, 3, 'uploads/placement_portal_project.zip', 3.80, '2015', 'inprocess', '2025-05-29 03:12:43', 3, '222', NULL),
(44, 15, 1, 'uploads/module_table_top.png', 3.80, '2022', '', '2025-05-29 19:33:00', 1, '121', NULL),
(45, 15, 3, 'uploads/module_table_bottom.png', 3.80, '2022', 'inprocess', '2025-05-29 19:33:15', 2, '121', NULL),
(46, 15, 5, 'uploads/labtest.html', 3.80, '2022', 'inprocess', '2025-05-29 19:33:29', 3, '121', NULL),
(47, 16, 5, 'uploads/placement_app_report (1).docx', 3.80, '2019', '', '2025-05-30 01:49:16', 1, '4', NULL),
(48, 16, 4, 'uploads/student_placements (5).xls', 3.80, '2019', 'inprocess', '2025-05-30 01:49:25', 2, '4', NULL),
(49, 16, 3, 'uploads/student_placements (5).xls', 3.80, '2019', 'inprocess', '2025-05-30 01:49:35', 3, '4', NULL),
(50, 17, 1, 'uploads/student_placements (5) (1).xls', 3.80, '2019', '', '2025-05-30 09:51:14', 1, '049', NULL),
(51, 17, 5, 'uploads/module_table_top.png', 3.80, '2019', 'inprocess', '2025-05-30 09:51:25', 2, '049', NULL),
(52, 17, 3, 'uploads/Placement_App_Project_Report.docx', 3.80, '2019', 'inprocess', '2025-05-30 09:51:43', 3, '4', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `finalplacements`
--

CREATE TABLE `finalplacements` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `orgid` int(11) NOT NULL,
  `placed_date` datetime DEFAULT current_timestamp(),
  `batch` varchar(10) DEFAULT NULL,
  `regno` varchar(20) DEFAULT NULL,
  `gpa` decimal(3,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'No Status'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `finalplacements`
--

INSERT INTO `finalplacements` (`id`, `userid`, `orgid`, `placed_date`, `batch`, `regno`, `gpa`, `status`) VALUES
(1, 5, 3, '2025-05-25 14:42:24', '2025', '056', 8.00, 'No Status'),
(2, 2, 3, '2025-05-25 14:42:24', '2022', '026', 4.50, 'Placed'),
(3, 3, 2, '2025-05-25 14:42:24', '2023', '002', 2.00, 'No Status'),
(4, 4, 3, '2025-05-25 14:42:24', NULL, '', NULL, 'No Status'),
(5, 6, 4, '2025-05-27 01:29:24', NULL, NULL, NULL, 'No Status'),
(6, 7, 1, '2025-05-27 05:32:47', '1969', '010', 3.40, 'No Status'),
(7, 8, 5, '2025-05-28 15:06:34', '2023', '005', 4.00, 'No Status'),
(8, 9, 2, '2025-05-28 15:14:03', '2021', '99', 3.80, 'No Status'),
(9, 10, 5, '2025-05-28 15:53:18', '2019', '112', 4.00, 'No Status'),
(10, 11, 5, '2025-05-28 16:27:23', '2012', '2060', 3.70, 'No Status'),
(11, 12, 1, '2025-05-29 00:47:33', '2019', '25', 4.00, 'No Status'),
(12, 13, 1, '2025-05-29 01:05:55', '2021', '333', 2.90, 'No Status'),
(13, 14, 1, '2025-05-29 03:13:39', '2015', '222', 3.80, 'No Status'),
(14, 15, 1, '2025-05-29 19:34:49', '2022', '121', 3.80, 'No Status'),
(15, 16, 5, '2025-05-30 01:49:44', '2019', '4', 3.80, 'No Status'),
(16, 17, 1, '2025-05-30 09:53:24', '2019', '049', 3.80, 'No Status');

-- --------------------------------------------------------

--
-- Table structure for table `organizations`
--

CREATE TABLE `organizations` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `domain` varchar(100) DEFAULT NULL,
  `seats` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `organizations`
--

INSERT INTO `organizations` (`id`, `name`, `location`, `domain`, `seats`) VALUES
(1, 'TechCorp', 'New York', 'IT', 11),
(2, 'FinancePlus', 'London', 'Finance', 5),
(3, 'EduWorld', 'San Francisco', 'Education', 8),
(4, 'NAYATEl', 'RAWALPINDi', 'IT', 4),
(5, 'SYNERGY', 'ISLAMABAD', 'IT', 5);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `regno` varchar(20) NOT NULL,
  `batch` varchar(50) DEFAULT NULL,
  `gpa` decimal(3,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `userid`, `regno`, `batch`, `gpa`) VALUES
(1, 2, '026', '2022', 4.50),
(2, 3, '002', '2023', 2.00),
(3, 4, '056', '2025', 8.00),
(4, 5, '033', '2015', 3.00),
(5, 6, '015', '2024', 4.00),
(6, 7, '010', '1969', 3.40),
(7, 8, '005', '2023', 4.00),
(8, 9, '99', '2021', 3.80),
(9, 10, '112', '2019', 4.00),
(10, 11, '2060', '2012', 3.70),
(11, 12, '25', '2019', 4.00),
(12, 13, '333', '2021', 2.90),
(13, 14, '222', '2015', 3.80),
(14, 15, '121', '2022', 3.80),
(15, 16, '4', '2019', 3.80),
(16, 17, '049', '2019', 3.80);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `regno` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','admin') NOT NULL DEFAULT 'student'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `regno`, `email`, `password`, `role`) VALUES
(1, 'ali abbas', '043', 'alicareu307@gmail.com', '$2y$10$rE495jUwtS9XHqJZgRePSu88iKs7ImITYV6zR.4tMjuMAWLhSLUvS', 'student'),
(2, 'mohid', '026', '', '$2y$10$mQnG2wcgzt6rlde.1zJQK.T0zOvSYRA3jb3tU6a5/WaGWh3lBPunu', 'student'),
(3, 'new', '002', 'new@gmail.com', '$2y$10$HRRleCW3eYxhob.FhB/HqOY48YrLtxI588.pAkMPiVAF.nNjtn2qK', 'student'),
(4, 'kashif', '056', 'kashif@gmail.com', '$2y$10$VzYTK3tMMEdC1Oi8C8pKL.M6uZHh8ZMIAbzsjU6vnd0ElgOuiEb62', 'student'),
(5, 'jj', '033', 'jj@gmail.com', '$2y$10$5yYq6DHtMOKljEtURCC/eOgztzHXAlEXOFs0/8.4nOSUK94qFc3i2', 'student'),
(6, 'MOMIN', '015', 'MOMIN@GMAIL.COM', '$2y$10$xCjO5omA0J0QJ8ZdqOiINuMJjajXHkxQ9KcPXyo/7D3rmEpjMOVgm', 'student'),
(7, 'ben10', '010', 'ben10@gmail.com', '$2y$10$tjyLnOCLJth1Kbq.Kg2zBO9TM04It8IzIdVthqhuBAFFnauKMh6vm', 'student'),
(8, 'haider', '005', 'haider@gmail.com', '$2y$10$Bobx4pIsTSNrR.n.EUyW7exjTi8XRmNdPvtBYHPfQz1tA7KJAcFDi', 'student'),
(9, 'usaidd', '99', 'usaid@gmail.com', '$2y$10$3p4dHB3YhVIK7f/82I47z.2kXuLtsSciCeX4zsEJs9F4ke.uaVD1.', 'student'),
(10, 'hi', '112', 'hi@gmail.com', '$2y$10$sh7j2wi5Hu7cXjNS6t0Th.5gBGM8q2fz8oyZZji1OO9D2OxtlyDNm', 'student'),
(11, 'laptop', '2060', 'lapyp@gmail.com', '$2y$10$kC2isvn88U/ww0TKb8.VJeecwPfeIWaL5ysll9V7gcuYIiBR7onSy', 'student'),
(12, 'santa', '25', 'santa@gmail.com', '$2y$10$RG9WTGqsEGQmPbifXQy4Bu2x5ET2earMw7FTterIlDxoq3vvE.TpK', 'student'),
(13, 'shoaib', '333', 'shoaib@hotmail.com', '$2y$10$UDhx7226tulleTYDKABQr.Jc0CSe86AHf5/aHbnrd84XtHoJk3Nti', 'student'),
(14, 'mm', '222', 'mm@gmail.com', '$2y$10$Qs980y5UD0Eh9rWHIPfGlOQDJWldljQz6dZqg0ZGQ6chuJjgcZr7C', 'student'),
(15, 'kk', '121', 'alicareu307@hotmail.com', '$2y$10$YhMBeIopkJ/8UBckjT8pYOGslvRVGnJxJoH0xOn80sMCPIaRzp5NC', 'student'),
(16, 'hassan', '4', 'hassan@gmail.com', '$2y$10$OqOtOArUlj/vLb864jShSOJVupd7NoIm0ylbvJHrj/oo32hE3Rgh.', 'student'),
(17, 'usama', '049', 'usama@gmail.com', '$2y$10$iZlLYy5Brv53rGAtilrdRuf/aYJKOhBVHPOL4kBjQm3OIwBXqTSr6', 'student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `consents`
--
ALTER TABLE `consents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`),
  ADD KEY `orgid` (`orgid`);

--
-- Indexes for table `finalplacements`
--
ALTER TABLE `finalplacements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`),
  ADD KEY `orgid` (`orgid`);

--
-- Indexes for table `organizations`
--
ALTER TABLE `organizations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `regno` (`regno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `consents`
--
ALTER TABLE `consents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `finalplacements`
--
ALTER TABLE `finalplacements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `organizations`
--
ALTER TABLE `organizations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `consents`
--
ALTER TABLE `consents`
  ADD CONSTRAINT `consents_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `consents_ibfk_2` FOREIGN KEY (`orgid`) REFERENCES `organizations` (`id`);

--
-- Constraints for table `finalplacements`
--
ALTER TABLE `finalplacements`
  ADD CONSTRAINT `finalplacements_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `finalplacements_ibfk_2` FOREIGN KEY (`orgid`) REFERENCES `organizations` (`id`);

--
-- Constraints for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
