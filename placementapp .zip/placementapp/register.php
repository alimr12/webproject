<?php
include 'includes/db.php';
session_start();

$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $regno = trim($_POST['regno']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $batch = trim($_POST['batch']); // Added batch
    $gpa = trim($_POST['gpa']); // Added GPA

    // Validate password
    if ($password !== $confirm_password) {
        $msg = "Passwords do not match.";
    } elseif (strlen($password) < 6) {
        $msg = "Password must be at least 6 characters.";
    } else {
        // Check if registration number or email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE regno = ? OR email = ?");
        $stmt->bind_param("ss", $regno, $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $msg = "Registration Number or Email already registered.";
        } else {
            // Insert user into users table
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $role = 'student';

            $insert_stmt = $conn->prepare("INSERT INTO users (name, regno, email, password, role) VALUES (?, ?, ?, ?, ?)");
            $insert_stmt->bind_param("sssss", $name, $regno, $email, $hashed_password, $role);

            if ($insert_stmt->execute()) {
                // Get the newly inserted user ID
                $userId = $conn->insert_id;

                // Now insert the student's additional details into the students table
                $insert_student_stmt = $conn->prepare("INSERT INTO students (userid, regno, batch, gpa) VALUES (?, ?, ?, ?)");
                $insert_student_stmt->bind_param("issd", $userId, $regno, $batch, $gpa);
                $insert_student_stmt->execute();

                // Redirect to the login page after successful registration
                header("Location: student/studentlogin.php?registered=1");
                exit();
            } else {
                $msg = "Error during registration. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Registration</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to right, #28a745, #007bff); /* Green to Blue Gradient */
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .register-box {
            background: #ffffff;
            border-radius: 15px;
            padding: 40px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }
        .register-box h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #007bff;
        }
        .register-box input[type="text"],
        .register-box input[type="email"],
        .register-box input[type="password"],
        .register-box input[type="number"] {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #f0f4ff;
        }
        .register-box button {
            width: 100%;
            padding: 12px;
            background-color: #28a745;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 10px;
            margin-top: 10px;
            cursor: pointer;
        }
        .register-box button:hover {
            background-color: #218838;
        }
        .register-box p {
            text-align: center;
            margin-top: 15px;
        }
        .register-box a {
            color: #fd7e14;
            text-decoration: none;
            font-weight: bold;
        }
        .register-box .alert {
            text-align: center;
            color: red;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="register-box">
        <h2>Student Registration</h2>
        <?php if ($msg): ?>
            <div class="alert"><?php echo $msg; ?></div>
        <?php endif; ?>
        <form method="POST">
            <input type="text" name="name" placeholder="Full Name" required>
            <input type="text" name="regno" placeholder="Registration Number" required>
            <input type="email" name="email" placeholder="Email (optional)">
            <input type="text" name="batch" placeholder="Batch (e.g., 2022)" required>
            <input type="number" name="gpa" placeholder="GPA (e.g., 3.9)" step="0.01" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <button type="submit">Register</button>
        </form>
        <p>Already have an account? <a href="student/studentlogin.php">Login here</a></p>
    </div>
</body>
</html>